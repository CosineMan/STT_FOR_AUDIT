"""Drive desktop batch orchestration with lightweight UI doubles and real workers."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tempfile, shutil, types, time
import stt_desktop

class Value:
    def __init__(self, value=None): self.value = value
    def set(self, value): self.value = value
    def get(self): return self.value

class Widget:
    buttons = []
    def __init__(self, *args, **kwargs):
        self.options = kwargs
        if kwargs.get('text') in ('開始轉錄', '取消作業'): self.buttons.append(self)
    def pack(self, **kwargs): pass
    def config(self, **kwargs): self.options.update(kwargs)
    def __setitem__(self, key, value): self.options[key] = value
    def delete(self, *args): pass
    def insert(self, *args): pass
    def see(self, *args): pass

class Root(Widget):
    def title(self, *args): pass
    def geometry(self, *args): pass
    def protocol(self, *args): pass
    def after(self, delay, callback): self.callback = callback
    def mainloop(self):
        start = Widget.buttons[-1]
        start.options['command']()
        time.sleep(1)
        self.buttons[-2].options['command']()
        deadline = time.monotonic() + 15
        while start.options.get('state') == 'disabled':
            assert time.monotonic() < deadline, 'Batch timed out'
            self.callback()
            time.sleep(0.05)
    def destroy(self): pass

root = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='v2-batch-', dir=root / 'build') as temp:
    temp = Path(temp)
    inputs = temp / '音檔'; inputs.mkdir()
    outputs = temp / '輸出'; outputs.mkdir()
    shutil.copyfile(root / 'build/smoke.wav', inputs / 'a.wav')
    (inputs / 'b.wav').write_text('invalid audio')
    shutil.copyfile(root / 'build/smoke.wav', inputs / 'c.wav')
    values = iter([str(inputs), str(outputs), 'en', False, 'ready'])
    def make_value(value=None): return Value(next(values))
    tk = types.ModuleType('tkinter')
    tk.Tk = Root; tk.StringVar = tk.BooleanVar = make_value; tk.Text = Widget
    tk.ttk = types.SimpleNamespace(**{name: Widget for name in ('Frame','Label','Entry','Button','Combobox','Checkbutton','Progressbar')})
    def unexpected(*args): raise AssertionError(args)
    tk.messagebox = types.SimpleNamespace(showerror=unexpected, askyesno=lambda *a: True)
    tk.filedialog = types.SimpleNamespace()
    sys.modules['tkinter'] = tk
    if '--frozen-test' in sys.argv:
        sys.executable = str(root / 'dist/OfflineSTT/OfflineSTT.exe')
        sys.frozen = True
    stt_desktop.main()
    reports = list(outputs.glob('本次執行紀錄_*.txt'))
    assert len(reports) == 1
    text = reports[0].read_text(encoding='utf-8-sig')
    assert '作業已取消' in text, text
    assert '未執行檔案' in text, text
    assert not (outputs / 'c_逐字稿.txt').exists()
    assert not (outputs / 'c_逐字稿.json').exists()
    (root / 'build/v3-cancel-report.txt').write_text(text, encoding='utf-8')
    print('PASS: Cancellation terminates real worker within deadline, skips remaining files, writes report')
