import unittest
from stt_with_large_v3 import align_words, assign_speaker, build_parser, validate_args


class AlignmentTests(unittest.TestCase):
    def test_accumulates_same_speaker(self):
        turns = [dict(start=0, end=0.4, speaker="A"),
                 dict(start=0, end=0.6, speaker="B"),
                 dict(start=0.6, end=1, speaker="A")]
        self.assertEqual(assign_speaker(0, 1, turns), ("A", ["A", "B"]))

    def test_no_overlap_and_boundary(self):
        turns = [dict(start=0, end=1, speaker="A")]
        self.assertEqual(assign_speaker(1, 2, turns), ("UNKNOWN", []))
        self.assertEqual(assign_speaker(0.5, 0.5, turns), ("A", ["A"]))
        self.assertEqual(assign_speaker(0, 1, []), ("UNKNOWN", []))

    def test_split_preserves_words(self):
        segments = [dict(start=0, end=2, text=" Hello world", words=[
            dict(start=0, end=1, text=" Hello"), dict(start=1, end=2, text=" world")])]
        turns = [dict(start=0, end=1, speaker="A"), dict(start=1, end=2, speaker="B")]
        rows = align_words(segments, turns)
        self.assertEqual([r["speaker"] for r in rows], ["A", "B"])
        self.assertEqual("".join(r["text"] for r in rows), " Hello world")
        self.assertEqual(len(align_words(segments, [], diarized=False)), 1)

    def test_segment_fallback(self):
        rows = align_words([dict(start=0, end=1, text="你好", words=[])], [])
        self.assertEqual(rows[0]["text"], "你好")
        self.assertEqual(rows[0]["speaker"], "UNKNOWN")

    def test_conflicting_counts(self):
        parser = build_parser()
        args = parser.parse_args([__file__, "--num-speakers", "2", "--max-speakers", "3"])
        with self.assertRaises(SystemExit):
            validate_args(parser, args)


if __name__ == "__main__":
    unittest.main()
