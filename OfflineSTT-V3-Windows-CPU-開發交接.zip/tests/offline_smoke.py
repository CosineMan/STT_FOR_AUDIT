"""Manual integration test: real inference with outbound socket connections blocked."""
import os
from pathlib import Path
import socket
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.pop('HF_TOKEN', None)
os.environ.pop('HUGGING_FACE_HUB_TOKEN', None)
os.environ['HF_HOME'] = str(Path('build/empty-hf-home').resolve())


def denied(*args, **kwargs):
    raise RuntimeError('Smoke test forbids network connections')


socket.socket.connect = denied
socket.create_connection = denied
from stt_with_large_v3 import main
sys.argv = ['stt', 'build/smoke.wav', '--offline-models', str(Path('models').resolve()),
            '--output', 'build/smoke-result.json', '--language', 'en']
raise SystemExit(main())
