from contextlib import redirect_stderr
import io
import logging
import unittest
import warnings

from stt_with_large_v3 import runtime_messages


class RuntimeMessagesTests(unittest.TestCase):
    def test_default_and_verbose_output(self):
        logger = logging.getLogger("speechbrain.test_runtime")
        previous = logger.level
        logger.setLevel(logging.DEBUG)
        try:
            for verbose in (False, True):
                output = io.StringIO()
                with redirect_stderr(output), warnings.catch_warnings():
                    warnings.simplefilter("always")
                    with runtime_messages(verbose):
                        logger.debug("checkpoint detail")
                        logger.warning("important warning")
                        logging.info("transcription progress")
                        for module, category, message in (
                            ("pandas.core.computation.expressions", UserWarning,
                             "Pandas requires version '2.10.2' or newer of 'numexpr' (version '2.8.7' currently installed)."),
                            ("speechbrain.utils.autocast", FutureWarning,
                             "`torch.cuda.amp.custom_fwd(args...)` is deprecated."),
                            ("lightning_fabric.utilities.cloud_io", FutureWarning,
                             "You are using `torch.load` with `weights_only=False` (the current default value)."),
                        ):
                            warnings.warn_explicit(message, category, "test.py", 1, module=module)
                        warnings.warn("unrelated warning", UserWarning)
                text = output.getvalue()
                for visible in ("important warning", "transcription progress", "unrelated warning"):
                    self.assertIn(visible, text)
                for detail in ("checkpoint detail", "Pandas requires", "custom_fwd", "weights_only"):
                    self.assertEqual(detail in text, verbose, text)
        finally:
            logger.setLevel(previous)
