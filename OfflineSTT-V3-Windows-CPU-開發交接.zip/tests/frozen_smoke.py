"""Exercise the real EXE from another cwd with empty caches and a minimal PATH."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    root = Path(__file__).resolve().parents[1]
    package = root / 'dist' / 'OfflineSTT'
    with tempfile.TemporaryDirectory(prefix='frozen-smoke-', dir=root / 'build') as temp:
        temp = Path(temp)
        audio = temp / '中文 測試音檔.wav'
        shutil.copyfile(root / 'build' / 'smoke.wav', audio)
        result = temp / '測試結果.json'
        log = temp / 'worker.log'
        environment = dict(os.environ)
        for name in ('HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN', 'PYTHONPATH', 'PYTHONHOME'):
            environment.pop(name, None)
        environment.update(HF_HOME=str(temp / 'hf'), TORCH_HOME=str(temp / 'torch'),
                           HF_HUB_OFFLINE='1', PATH=str(Path(os.environ['SystemRoot']) / 'System32'))
        command = [str(package / 'OfflineSTT.exe'), '--worker', str(audio),
                   '--offline-models', str(package / 'models'), '--language', 'en',
                   '--output', str(result), '--worker-log', str(log)]
        completed = subprocess.run(command, cwd=temp, env=environment, timeout=600)
        text = log.read_text(encoding='utf-8') if log.exists() else 'No worker log created'
        (root / 'build' / 'frozen-smoke.log').write_text(text, encoding='utf-8')
        if completed.returncode:
            raise RuntimeError(f'EXE failed ({completed.returncode}):\n{text}')
        progress = [json.loads(line.removeprefix('STT_PROGRESS ')) for line in text.splitlines() if line.startswith('STT_PROGRESS ')]
        assert progress and progress[-1]['percent'] == 100, 'Missing completion progress'
        assert all(a['percent'] <= b['percent'] for a, b in zip(progress, progress[1:])), 'Progress regressed'
        data = json.loads(result.read_text(encoding='utf-8'))
        assert data['segments'], 'No transcript segments'
        assert data['diarization_turns'], 'No speaker turns'
        assert result.with_suffix('.txt').stat().st_size > 0, 'No TXT output'
        print('PASS: EXE transcription + diarization, Chinese/spaced paths, empty caches, minimal PATH')
        # Missing models must fail promptly with a useful message rather than download.
        command[command.index('--offline-models') + 1] = str(temp / 'missing-models')
        failed = subprocess.run(command, cwd=temp, env=environment, timeout=60)
        assert failed.returncode != 0
        assert '離線模型不完整' in log.read_text(encoding='utf-8')
        print('PASS: Missing model gives an offline error')


if __name__ == '__main__':
    main()
