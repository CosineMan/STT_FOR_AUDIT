import sys
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

from stt_with_large_v3 import speechbrain_copy_on_windows


class CopyStrategyTests(unittest.TestCase):
    def test_copy_for_initial_load_and_device_reload_and_restore(self):
        calls = []

        class Classifier:
            @classmethod
            def from_hparams(cls, *args, **kwargs):
                calls.append((args, kwargs))
                return cls()

        verification = SimpleNamespace(SpeechBrain_EncoderClassifier=Classifier)
        pipelines = ModuleType("pyannote.audio.pipelines")
        pipelines.speaker_verification = verification
        fetching = ModuleType("speechbrain.utils.fetching")
        fetching.LocalStrategy = SimpleNamespace(COPY=object())
        modules = {"pyannote.audio.pipelines": pipelines,
                   "speechbrain.utils.fetching": fetching}
        with patch.dict(sys.modules, modules), patch("stt_with_large_v3.os.name", "nt"):
            with self.assertRaisesRegex(RuntimeError, "load failed"):
                with speechbrain_copy_on_windows():
                    for device in ("cpu", "cuda"):
                        verification.SpeechBrain_EncoderClassifier.from_hparams(
                            "model", run_opts={"device": device}, revision="revision")
                    raise RuntimeError("load failed")
            self.assertIs(verification.SpeechBrain_EncoderClassifier, Classifier)
        self.assertEqual(len(calls), 2)
        for args, kwargs in calls:
            self.assertEqual(args, ("model",))
            self.assertIs(kwargs["local_strategy"], fetching.LocalStrategy.COPY)
            self.assertEqual(kwargs["revision"], "revision")
        self.assertEqual([kwargs["run_opts"]["device"] for _, kwargs in calls],
                         ["cpu", "cuda"])

    def test_other_platforms_do_not_import_speechbrain(self):
        with patch("stt_with_large_v3.os.name", "posix"), patch.dict(
            sys.modules, {"speechbrain.utils.fetching": None}
        ):
            with speechbrain_copy_on_windows():
                pass

    def test_local_model_overrides_remote_source_and_token(self):
        calls = []

        class Classifier:
            @classmethod
            def from_hparams(cls, *args, **kwargs):
                calls.append(kwargs)
                return cls()

        verification = SimpleNamespace(SpeechBrain_EncoderClassifier=Classifier)
        pipelines = ModuleType("pyannote.audio.pipelines")
        pipelines.speaker_verification = verification
        fetching = ModuleType("speechbrain.utils.fetching")
        fetching.LocalStrategy = SimpleNamespace(COPY=object())
        from pathlib import Path
        source = Path('models/speaker-embedding').resolve()
        with patch.dict(sys.modules, {"pyannote.audio.pipelines": pipelines,
                                     "speechbrain.utils.fetching": fetching}):
            with speechbrain_copy_on_windows(source):
                verification.SpeechBrain_EncoderClassifier.from_hparams(
                    source='remote/model', use_auth_token='private-token', savedir='old-cache')
        self.assertEqual(calls[0]['source'], str(source))
        self.assertIs(calls[0]['use_auth_token'], False)
        self.assertEqual(calls[0]['overrides'], {'pretrained_path': source.as_posix()})
        self.assertNotEqual(calls[0]['savedir'], 'old-cache')
