import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from offline_models import FILES, configure_offline, validate_models


class OfflineTests(unittest.TestCase):
    def test_asr_only_does_not_require_diarization(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            folder = root / 'whisper-large-v3-turbo'
            folder.mkdir()
            for name in FILES[folder.name]:
                (folder / name).touch()
            validate_models(root, False)
            with self.assertRaisesRegex(ValueError, 'segmentation'):
                validate_models(root, True)

    def test_offline_overrides_online_environment(self):
        with patch.dict(os.environ, {'HF_HUB_OFFLINE': '0'}):
            configure_offline()
            self.assertEqual(os.environ['HF_HUB_OFFLINE'], '1')
            self.assertEqual(os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN'], '1')
