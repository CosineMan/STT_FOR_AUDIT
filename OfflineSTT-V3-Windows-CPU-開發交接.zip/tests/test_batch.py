import tempfile
from pathlib import Path
import unittest
from opencc import OpenCC
from stt_desktop import discover_audio, plan_outputs

class BatchTests(unittest.TestCase):
    def test_folder_filters_sorts_and_avoids_collisions(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for name in ('會議.wav', '會議.MP3', 'notes.txt', 'other.m4a'):
                (root / name).touch()
            (root / 'nested').mkdir()
            (root / 'nested' / 'hidden.wav').touch()
            files = discover_audio(root)
            self.assertEqual(len(files), 3)
            results = plan_outputs(files, root)
            self.assertEqual(len(set(results)), 3)
            self.assertTrue(any(p.stem.endswith('_2') for p in results))
            self.assertEqual(discover_audio(root / 'other.m4a'), [root / 'other.m4a'])

    def test_traditional_conversion(self):
        converter = OpenCC('s2twp')
        self.assertEqual(converter.convert('这是语音转文字测试，软件和网络。'), '這是語音轉文字測試，軟體和網路。')
        self.assertEqual(converter.convert('English 123'), 'English 123')

    def test_progress_protocol(self):
        import io, json
        from contextlib import redirect_stdout
        from stt_with_large_v3 import report_progress
        stream = io.StringIO()
        with redirect_stdout(stream):
            report_progress(42.5, '語音轉文字')
        update = json.loads(stream.getvalue().removeprefix('STT_PROGRESS '))
        self.assertEqual(update, {'percent': 42.5, 'stage': '語音轉文字'})
