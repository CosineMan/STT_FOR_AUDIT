"""Copy only model snapshots, never account credentials, into the release."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
from offline_models import FILES, validate_models


# 交接註解：從既有本機快取選取唯一完整 snapshot；不下載模型。複製實體檔並建立修訂與雜湊清單。
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--destination", type=Path, default=Path("models"))
    parser.add_argument("--cache-root", type=Path, default=Path.home() / ".cache")
    args = parser.parse_args()
    repos = {
        "whisper-large-v3-turbo": ("huggingface/hub", "mobiuslabsgmbh/faster-whisper-large-v3-turbo"),
        "segmentation": ("torch/pyannote", "pyannote/segmentation-3.0"),
        "speaker-embedding": ("huggingface/hub", "speechbrain/spkrec-ecapa-voxceleb"),
    }
    manifest = {}
    for folder, (cache, repo) in repos.items():
        base = args.cache_root / cache / ("models--" + repo.replace("/", "--"))
        ref = base / "refs" / "main"
        candidates = [base / "snapshots" / ref.read_text().strip()] if ref.exists() else sorted((base / "snapshots").glob("*"))
        valid = [p for p in candidates if all((p / name).is_file() for name in FILES[folder])]
        if len(valid) != 1:
            raise SystemExit(f"找不到唯一完整模型快取：{repo}，請先在開發電腦下載完整模型。")
        source = valid[0]
        target = args.destination / folder
        target.mkdir(parents=True, exist_ok=True)
        # Dereference snapshot links, include configuration and available model licenses.
        hashes = {}
        for src in source.rglob("*"):
            if not src.is_file():
                continue
            dest = target / src.relative_to(source)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
            with dest.open("rb") as stream:
                hashes[src.relative_to(source).as_posix()] = hashlib.file_digest(stream, "sha256").hexdigest()
        manifest[folder] = {"repository": repo, "revision": source.name, "sha256": hashes}
        if folder == "speaker-embedding" and not (target / "custom.py").exists():
            # SpeechBrain 1.0.3 does not catch missing optional LOCAL custom.py.
            stub = b'# No custom classes are needed by ECAPA-TDNN.\n'
            (target / "custom.py").write_bytes(stub)
            hashes["custom.py"] = hashlib.sha256(stub).hexdigest()
            manifest[folder]["generated_files"] = ["custom.py"]
        print(f"已準備 {folder}", flush=True)
    validate_models(args.destination)
    (args.destination / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
