from PyInstaller.utils.hooks import collect_all, collect_data_files, copy_metadata

# 交接註解：收集動態匯入與套件資料；模型由 build_offline.ps1 在打包後另行複製。
datas, binaries, hiddenimports = [], [], []
for package in ('faster_whisper', 'ctranslate2', 'pyannote.audio', 'speechbrain', 'opencc'):
    d, b, h = collect_all(package)
    datas += d
    binaries += b
    hiddenimports += h
for package in ('torch', 'torchaudio', 'pyannote.audio', 'speechbrain', 'huggingface-hub'):
    datas += copy_metadata(package)
for package in ('lightning_fabric', 'lightning', 'pytorch_lightning'):
    datas += collect_data_files(package)
hiddenimports += ['pyannote.audio.models.segmentation.PyanNet', 'speechbrain.lobes.models.ECAPA_TDNN']
# 交接註解：桌面為唯一 PyInstaller 入口；onedir 配置必須交付完整資料夾，不能只交付 EXE。
a = Analysis(['stt_desktop.py'], pathex=[], binaries=binaries, datas=datas,
             hiddenimports=hiddenimports, hookspath=[], runtime_hooks=[],
             excludes=['IPython', 'notebook', 'pytest', 'tensorboard', 'torchvision'], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='OfflineSTT',
          debug=False, bootloader_ignore_signals=False, strip=False, upx=False, console=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='OfflineSTT')
