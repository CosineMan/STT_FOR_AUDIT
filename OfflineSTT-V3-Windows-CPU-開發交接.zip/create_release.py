"""Validate model payloads and build a portable ZIP with a SHA256 sidecar."""
import hashlib
import json
from pathlib import Path
import zipfile


# 交接註解：僅對 dist/OfflineSTT 產物操作：核對模型 manifest、封裝 ZIP、驗證 CRC、輸出 SHA256。
def main():
    package = Path(__file__).resolve().parent / 'dist' / 'OfflineSTT'
    manifest = json.loads((package / 'models' / 'manifest.json').read_text(encoding='utf-8'))
    for folder, entry in manifest.items():
        for name, expected in entry['sha256'].items():
            with (package / 'models' / folder / name).open('rb') as stream:
                actual = hashlib.file_digest(stream, 'sha256').hexdigest()
            if actual != expected:
                raise RuntimeError(f'Model checksum mismatch: {folder}/{name}')
    print('All model SHA256 checks passed', flush=True)
    files = sorted(p for p in package.rglob('*') if p.is_file())
    forbidden = {'.env', 'token', 'stored_tokens'}
    if any(p.name.lower() in forbidden for p in files):
        raise RuntimeError('Credential-like filename found in package')
    archive = package.parent / 'OfflineSTT-V3-Windows-CPU.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=1,
                         allowZip64=True) as output:
        for path in files:
            output.write(path, path.relative_to(package.parent))
    with zipfile.ZipFile(archive) as output:
        bad = output.testzip()
        if bad:
            raise RuntimeError(f'ZIP integrity failure: {bad}')
    with archive.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    archive.with_suffix('.zip.sha256').write_text(f'{digest}  {archive.name}\n', encoding='ascii')
    print(f'ZIP verified: {archive} ({archive.stat().st_size:,} bytes)', flush=True)
    print(f'Unpacked: {sum(p.stat().st_size for p in files):,} bytes; {len(files)} files', flush=True)


if __name__ == '__main__':
    main()
