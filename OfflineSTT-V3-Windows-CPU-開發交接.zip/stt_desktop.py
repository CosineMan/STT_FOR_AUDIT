"""CPU-only offline desktop entry point and subprocess worker."""
import os
import json
from datetime import datetime
from pathlib import Path
import queue
import subprocess
import sys
import threading
import tempfile
import time
from offline_models import app_root, configure_offline, validate_models


AUDIO_EXTENSIONS = {".wav", ".mp3", ".m4a", ".flac", ".ogg", ".mp4", ".aac", ".wma", ".aiff", ".aif", ".opus", ".webm"}


# 交接註解：輸入單檔直接回傳；資料夾只掃描當層支援副檔名，依檔名不分大小寫排序。
def discover_audio(source):
    source = Path(source)
    if source.is_file():
        return [source]
    if source.is_dir():
        return sorted((p for p in source.iterdir() if p.is_file() and p.suffix.lower() in AUDIO_EXTENSIONS),
                      key=lambda p: p.name.casefold())
    return []


# 交接註解：只消除本批次的同名輸出；磁碟既有檔案的覆寫確認由 start 處理。
def plan_outputs(files, destination):
    used = set()
    results = []
    for audio in files:
        base = f"{audio.stem}_逐字稿"
        name = base
        counter = 1
        while name.casefold() in used:
            counter += 1
            name = f"{base}_{counter}"
        used.add(name.casefold())
        results.append(Path(destination) / f"{name}.json")
    return results


# 交接註解：同一入口兼任 Tk 桌面與 --worker 子程序；離線設定先於第三方模型匯入。
def main():
    configure_offline()
    if "--worker" in sys.argv:
        if "--worker-log" in sys.argv:
            index = sys.argv.index("--worker-log")
            logfile = sys.argv[index + 1]
            del sys.argv[index:index + 2]
            sys.stdout = sys.stderr = open(logfile, "w", encoding="utf-8", buffering=1)
        from stt_with_large_v3 import main as worker
        sys.argv.remove("--worker")
        return worker()
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    root = tk.Tk()
    root.title("語音轉文字 V3")
    root.geometry("850x620")
    audio = tk.StringVar()
    output = tk.StringVar(value=str(Path.home() / "Documents"))
    language = tk.StringVar(value="auto")
    diarization = tk.BooleanVar(value=True)
    status = tk.StringVar(value="CPU 離線模式｜選擇音檔或資料夾後開始")
    events = queue.Queue()
    process = None
    busy = False
    cancelled = threading.Event()
    panel = ttk.Frame(root, padding=18)
    panel.pack(fill="both", expand=True)

    def select_audio():
        path = filedialog.askopenfilename(filetypes=[("音訊", "*.wav *.mp3 *.m4a *.flac *.ogg *.mp4"), ("全部檔案", "*.*")])
        if path:
            audio.set(path)

    def select_folder():
        path = filedialog.askdirectory(title="選擇音檔資料夾（不含子資料夾）")
        if path:
            audio.set(path)

    def select_output():
        path = filedialog.askdirectory()
        if path:
            output.set(path)

    for label, variable, callback in (("音檔或資料夾（批次處理不含子資料夾）", audio, select_audio), ("輸出資料夾", output, select_output)):
        ttk.Label(panel, text=label).pack(anchor="w")
        row = ttk.Frame(panel)
        row.pack(fill="x", pady=(3, 10))
        ttk.Entry(row, textvariable=variable).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="選擇音檔…" if variable is audio else "選擇…", command=callback).pack(side="right", padx=(8, 0))
        if variable is audio:
            ttk.Button(row, text="選擇資料夾…", command=select_folder).pack(side="right", padx=(8, 0))
    row = ttk.Frame(panel)
    row.pack(fill="x")
    ttk.Label(row, text="語言").pack(side="left")
    ttk.Combobox(row, textvariable=language, values=("auto", "zh", "en", "ja"), state="readonly", width=10).pack(side="left", padx=8)
    ttk.Checkbutton(row, text="辨識不同發言者（較耗時）", variable=diarization).pack(side="left")
    ttk.Label(panel, textvariable=status).pack(anchor="w", pady=10)
    progress = ttk.Progressbar(panel, mode="determinate", maximum=100)
    progress.pack(fill="x")
    log = tk.Text(panel, height=14, state="disabled", wrap="word")
    log.pack(fill="both", expand=True, pady=10)

    # 交接註解：背景執行緒逐檔啟動獨立 worker；透過 Queue 通知 UI，不直接操作 Tk 元件。
    def collect(jobs, environment, report):
        nonlocal process
        records = []
        started = datetime.now().astimezone().isoformat(timespec="seconds")
        # 交接註解：每次更新重寫 UTF-8 BOM 執行紀錄；-999 是本介面使用的取消狀態碼。
        def save_report():
            lines = ["語音轉文字 V3 執行紀錄", f"開始時間：{started}",
                     f"更新時間：{datetime.now().astimezone().isoformat(timespec='seconds')}",
                     f"總檔數：{len(jobs)}；已處理：{len(records)}；成功：{sum(r[1] == 0 for r in records)}；失敗：{sum(r[1] not in (0, -999) for r in records)}", "",
                     "本次檔案清單："]
            lines += [str(source.resolve()) for source, _, _ in jobs]
            lines += ["", "執行結果："]
            for source, code, result, detail in records:
                lines += [f"{'成功' if code == 0 else ('已取消' if code == -999 else '失敗')}：{source.resolve()}",
                          f"輸出：{result} / {result.with_suffix('.txt')}" if code == 0 else f"錯誤：{detail}"]
            if cancelled.is_set():
                lines += ["", "作業已取消；目前中斷的檔案輸出可能不完整，請重新轉錄。", "未執行檔案："]
                lines += [str(source.resolve()) for source, _, _ in jobs[len(records):]]
            report.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
        try:
            save_report()
            for index, (source, result, command) in enumerate(jobs):
                if cancelled.is_set():
                    break
                events.put(("progress", (100 * index / len(jobs), f"[{index + 1}/{len(jobs)}] {source.name}｜準備中")))
                events.put(("log", f"\n[{index + 1}/{len(jobs)}] {source.name}\n"))
                detail = ""
                try:
                    with tempfile.TemporaryDirectory(prefix="stt-log-") as temp:
                        logfile = Path(temp) / "worker.log"
                        logfile.touch()
                        process = subprocess.Popen(command + ["--worker-log", str(logfile)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=environment,
                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
                        with logfile.open(encoding="utf-8", errors="replace") as stream:
                            pending = ""
                            while True:
                                # 交接註解：取消採終止目前子程序，三秒後仍未退出則 kill；不保證正在寫入的結果完整。
                                if cancelled.is_set() and process.poll() is None:
                                    process.terminate()
                                    try:
                                        process.wait(timeout=3)
                                    except subprocess.TimeoutExpired:
                                        process.kill()
                                        process.wait()
                                pending += stream.read()
                                lines = pending.split("\n")
                                pending = lines.pop()
                                for line in lines:
                                    # 交接註解：辨識機器可讀進度行；其餘文字顯示於日誌。整批百分比按檔案數等權平均。
                                    if line.startswith("STT_PROGRESS "):
                                        try:
                                            update = json.loads(line[len("STT_PROGRESS "):])
                                            percent = max(0, min(100, float(update["percent"])))
                                            events.put(("progress", (100 * (index + percent / 100) / len(jobs),
                                                f"[{index + 1}/{len(jobs)}] {source.name}｜{update['stage']} {percent:.0f}%")))
                                            continue
                                        except (ValueError, KeyError, TypeError):
                                            pass
                                    detail = line or detail
                                    events.put(("log", line + "\n"))
                                if process.poll() is not None:
                                    remaining = stream.read()
                                    if remaining:
                                        pending += remaining
                                        continue
                                    if pending:
                                        events.put(("log", pending + "\n"))
                                    break
                                time.sleep(0.2)
                        code = process.returncode
                except Exception as error:
                    code, detail = 1, str(error)
                    events.put(("log", f"執行失敗：{error}\n"))
                if cancelled.is_set() and code != 0:
                    code, detail = -999, "使用者取消作業"
                records.append((source, code, result, detail))
                save_report()
                if cancelled.is_set():
                    break
                events.put(("progress", (100 * (index + 1) / len(jobs), f"已處理 {index + 1}/{len(jobs)} 個檔案")))
            save_report()
            if cancelled.is_set():
                events.put(("done", f"已取消作業，已完成結果保留。紀錄：{report}"))
                return
            failures = sum(r[1] not in (0, -999) for r in records)
            events.put(("done", f"完成：成功 {len(records) - failures}，失敗 {failures}。紀錄：{report}"))
        except Exception as error:
            events.put(("done", f"批次處理中止：{error}"))

    # 交接註解：先驗證模型、輸入與輸出，再建立 worker 命令；原始碼與 frozen EXE 的啟動參數不同。
    def start():
        nonlocal busy
        try:
            validate_models(app_root() / "models", diarization.get())
            files = discover_audio(audio.get()) if audio.get() else []
            if not files:
                raise ValueError("請選擇存在的音檔，或含支援音檔的資料夾。")
            if not output.get() or not Path(output.get()).is_dir():
                raise ValueError("請選擇存在的輸出資料夾。")
            results = plan_outputs(files, output.get())
            if any(p.exists() for result in results for p in (result, result.with_suffix(".txt"))):
                if not messagebox.askyesno("覆寫確認", "部分同名逐字稿已存在，是否覆寫？"):
                    return
            jobs = []
            for source, result in zip(files, results):
                command = [sys.executable]
                if not getattr(sys, "frozen", False):
                    command.append(str(Path(__file__).resolve()))
                command += ["--worker", str(source), "--offline-models", str(app_root() / "models"),
                            "--language", language.get(), "--output", str(result)]
                if not diarization.get():
                    command.append("--no-diarization")
                if language.get() == "zh":
                    command += ["--initial-prompt", "以下是繁體中文的逐字稿。"]
                jobs.append((source, result, command))
            report = Path(output.get()) / ("本次執行紀錄_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".txt")
            environment = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
            cancelled.clear()
            cancel_button.config(state="normal")
            busy = True
            button.config(state="disabled")
            status.set("處理中，長錄音與語者分離可能需要較久時間…")
            log.config(state="normal")
            log.delete("1.0", "end")
            log.config(state="disabled")
            progress["value"] = 0
            threading.Thread(target=collect, args=(jobs, environment, report), daemon=True).start()
        except Exception as error:
            messagebox.showerror("無法開始", str(error))

    # 交接註解：僅設定取消旗標；實際終止由 collect 的輪詢處理，避免 UI 執行緒等待。
    def cancel():
        if busy:
            cancelled.set()
            cancel_button.config(state="disabled")
            status.set("正在取消作業，請稍候…")

    cancel_button = ttk.Button(panel, text="取消作業", command=cancel, state="disabled")
    cancel_button.pack()
    button = ttk.Button(panel, text="開始轉錄", command=start)
    button.pack()

    # 交接註解：Tk 主執行緒每 100 ms 消費事件；done 事件恢復按鈕，允許重新開始。
    def poll():
        nonlocal busy, process
        while not events.empty():
            kind, value = events.get_nowait()
            if kind == "log":
                log.config(state="normal")
                log.insert("end", value)
                log.see("end")
                log.config(state="disabled")
            elif kind == "progress":
                if cancelled.is_set():
                    continue
                percent, label = value
                progress["value"] = percent
                status.set(f"{label}｜整批 {percent:.1f}%")
            else:
                busy = False
                process = None
                button.config(state="normal")
                cancel_button.config(state="disabled")
                status.set(value)
                log.config(state="normal")
                log.insert("end", "\n" + value + "\n")
                log.config(state="disabled")
        root.after(100, poll)

    # 交接註解：忙碌時阻止直接關閉視窗；須先取消並等背景工作結束。
    def close():
        if busy:
            messagebox.showinfo("正在處理", "請等待本次轉錄完成後再關閉視窗。")
            return
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", close)
    poll()
    root.mainloop()
    return 0


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    raise SystemExit(main())
