# OfflineSTT V3 Windows CPU 開發交接

交接整理日期：2026-11-02。此資料夾包含可獨立開發的原始碼、原有測試、離線模型與既有第三方授權告知。

1. 先讀 `docs/開發環境建置.md`，建立 Python 3.12.7 環境。
2. 依 `docs/開發手冊.md` 理解架構、輸出與建置流程。
3. 參考 `docs/環境套件完整清單.md` 與 `requirements-build.lock.txt` 核對全部版本。
4. `docs/改善建議.md` 是獨立的未實作建議，不屬於這次程式修改。
5. `docs/驗證與交接範圍.md` 說明此次證據與未完成驗收。

產品 Python 程式與 PyInstaller spec 僅加入 # 註解，沒有改動既有語句、字串或 docstring；AST 與非註解 token 比對結果位於 `evidence/source-equivalence.json`。PowerShell 僅前置一行註解。原專案沒有被改寫。

本交接以目前工作目錄的 V3 原始碼為基準。已比對 V3 ZIP 的模型 manifest 與發佈套件版本；原 ZIP 沒有原始碼版控識別，無法證明目前原始碼逐位元對應當時 EXE。交接包未包含 EXE、舊版 ZIP、虛擬環境、帳戶快取或私人音檔。隨附模型可直接供原始碼使用；重新建置會產生新的 dist/OfflineSTT。

文件以 UTF-8 Markdown 提供，方便接手團隊直接納入版本控制。`evidence/original-README.md` 與原驗證記錄保留作為歷史資料；其中 Python 3.10/3.11、V2 檔名與進度敘述有過時內容，請以本次手冊與程式為準。
