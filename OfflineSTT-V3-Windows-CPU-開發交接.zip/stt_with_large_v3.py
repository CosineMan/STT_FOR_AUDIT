"""Local Whisper transcription and speaker diarization. See README.md."""
from __future__ import annotations

import argparse
from collections import defaultdict
from contextlib import contextmanager
import gc
import json
import logging
import os
from pathlib import Path
import time
import warnings

ASR_MODEL = "mobiuslabsgmbh/faster-whisper-large-v3-turbo"
SEGMENTATION_MODEL = "pyannote/segmentation-3.0"
EMBEDDING_MODEL = "speechbrain/spkrec-ecapa-voxceleb"
SAMPLE_RATE = 16000


# 交接註解：stdout 協定：固定前綴加單行 JSON；桌面 worker 會將 stdout/stderr 導向暫存日誌。
def report_progress(percent, stage):
    print("STT_PROGRESS " + json.dumps({"percent": percent, "stage": stage}, ensure_ascii=False), flush=True)


# 交接註解：保留警告與錯誤，僅降低特定第三方套件的日誌噪音。
class ConsoleLogFilter(logging.Filter):
    """Keep application progress and third-party warnings/errors visible."""

    def filter(self, record):
        noisy = record.name.split(".", 1)[0] in {"speechbrain", "numexpr"}
        return not noisy or record.levelno >= logging.WARNING


@contextmanager
# 交接註解：暫時安裝日誌及警告過濾，離開 context 時還原；不改變模型載入行為。
def runtime_messages(verbose=False):
    # Filter the handler: child loggers can explicitly enable DEBUG themselves.
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    if not verbose:
        handler.addFilter(ConsoleLogFilter())
    root = logging.getLogger()
    previous_level = root.level
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    try:
        with warnings.catch_warnings():
            if not verbose:
                warnings.filterwarnings(
                    "ignore",
                    message=r"Pandas requires version .* of '(numexpr|bottleneck)' .*",
                    category=UserWarning, module=r"pandas\..*",
                )
                warnings.filterwarnings(
                    "ignore", message=r".*torch\.cuda\.amp\.custom_fwd.*deprecated.*",
                    category=FutureWarning, module=r"speechbrain\.utils\.autocast",
                )
                warnings.filterwarnings(
                    "ignore", message=r"You are using `torch\.load` with `weights_only=False`.*",
                    category=FutureWarning,
                    module=r"(lightning_fabric\.utilities\.cloud_io|speechbrain\.utils\.checkpoints|speechbrain\.processing\.features)",
                )
            yield
    finally:
        root.removeHandler(handler)
        root.setLevel(previous_level)
        handler.close()


# 交接註解：turns 須依 start 排序；累加各語者時間重疊，平手按標籤排序，無重疊為 UNKNOWN。
def assign_speaker(start, end, turns):
    """Accumulate overlap per speaker; leave unmatched words UNKNOWN."""
    scores = defaultdict(float)
    for turn in turns:
        if turn["start"] > end:
            break
        overlap = max(0.0, min(end, turn["end"]) - max(start, turn["start"]))
        if overlap > 0:
            scores[turn["speaker"]] += overlap
        elif start == end and turn["start"] <= start < turn["end"]:
            scores[turn["speaker"]] += 1.0
    ranked = sorted(scores, key=lambda speaker: (-scores[speaker], speaker))
    return (ranked[0] if ranked else "UNKNOWN"), ranked


# 交接註解：按逐字主要語者切段；缺逐字時間則使用整段，停用分離時標記 UNASSIGNED。
def align_words(segments, turns, diarized=True):
    """Split each ASR segment at word-level speaker changes."""
    rows = []
    for segment in segments:
        current = None
        units = segment["words"] or [{key: segment[key] for key in ("start", "end", "text")}]
        for unit in units:
            speaker, candidates = assign_speaker(unit["start"], unit["end"], turns)
            if not diarized:
                speaker, candidates = "UNASSIGNED", []
            word = {**unit, "speaker": speaker, "speaker_candidates": candidates}
            if current is None or current["speaker"] != speaker:
                current = {"start": unit["start"], "end": unit["end"],
                           "speaker": speaker, "text": unit["text"], "words": [word]}
                rows.append(current)
            else:
                current["end"] = max(current["end"], unit["end"])
                current["text"] += unit["text"]
                current["words"].append(word)
    return rows


@contextmanager
# 交接註解：短暫替換 pyannote 使用的分類器以改採 COPY；finally 還原，全域替換不適合並行初始化。
def speechbrain_copy_on_windows(local_source=None):
    """Adapt pyannote 3.3's loader without changing installed packages."""
    if os.name != "nt" and local_source is None:
        yield
        return
    from pyannote.audio.pipelines import speaker_verification
    from speechbrain.utils.fetching import LocalStrategy

    original = speaker_verification.SpeechBrain_EncoderClassifier

    class CopyEncoderClassifier(original):
        @classmethod
        def from_hparams(cls, *args, **kwargs):
            kwargs["local_strategy"] = LocalStrategy.COPY
            if local_source is not None:
                import tempfile
                kwargs.update(source=str(local_source), use_auth_token=False,
                              overrides={"pretrained_path": Path(local_source).as_posix()})
                # A private writable directory also works when the app is read-only.
                with tempfile.TemporaryDirectory(prefix="stt-speaker-") as savedir:
                    kwargs["savedir"] = savedir
                    return super().from_hparams(*args, **kwargs)
            return super().from_hparams(*args, **kwargs)

    speaker_verification.SpeechBrain_EncoderClassifier = CopyEncoderClassifier
    try:
        yield
    finally:
        speaker_verification.SpeechBrain_EncoderClassifier = original


# 交接註解：自訂 segmentation + ECAPA + 聚類流程；與 Whisper 分開選擇裝置，回傳排序後活動區間。
def diarize(audio, args, token):
    import torch
    from pyannote.audio.pipelines import SpeakerDiarization

    # Explicit embedding selection avoids bundled pipelines using WeSpeaker.
    local_root = getattr(args, "offline_models", None)
    with speechbrain_copy_on_windows(local_root / "speaker-embedding" if local_root else None):
        pipeline = SpeakerDiarization(
            segmentation=str(local_root / "segmentation" / "pytorch_model.bin") if local_root else SEGMENTATION_MODEL,
            embedding=EMBEDDING_MODEL,
            embedding_exclude_overlap=True, clustering="AgglomerativeClustering",
            use_auth_token=token,
        )
        if args.diarization_device == "cuda":
            if not torch.cuda.is_available():
                raise ValueError("PyTorch CUDA 不可用，請改用 --diarization-device cpu")
            pipeline.to(torch.device("cuda"))
    # Initial settings for this custom combination, not a benchmark-tuned recipe.
    pipeline.instantiate({
        "segmentation": {"min_duration_off": 0.0},
        "clustering": {"method": "centroid", "min_cluster_size": 12,
                       "threshold": args.cluster_threshold},
    })
    counts = {key: getattr(args, key) for key in
              ("num_speakers", "min_speakers", "max_speakers")
              if getattr(args, key) is not None}
    with torch.inference_mode():
        annotation = pipeline(
            {"waveform": torch.from_numpy(audio).unsqueeze(0), "sample_rate": SAMPLE_RATE},
            **counts,
        )
    turns = sorted(
        ({"start": float(turn.start), "end": float(turn.end), "speaker": str(speaker)}
         for turn, _, speaker in annotation.itertracks(yield_label=True)),
        key=lambda turn: (turn["start"], turn["end"], turn["speaker"]),
    )
    del pipeline
    gc.collect()
    if args.diarization_device == "cuda":
        torch.cuda.empty_cache()
    return turns


# 交接註解：CLI 的完整選項與預設值集中於此；桌面介面僅開放其中一部分。
def build_parser():
    parser = argparse.ArgumentParser(description="Whisper large-v3-turbo 轉錄與語者分離")
    parser.add_argument("audio", nargs="?", type=Path, default=Path("cnn_anderson_cooper.m4a"))
    parser.add_argument("--language", default="auto", help="auto、zh、en 等語言代碼")
    parser.add_argument("--initial-prompt", help="選填提示詞，不保證輸出繁體中文")
    parser.add_argument("--model-dir", type=Path, help="包含 model.bin 的本機 CTranslate2 模型目錄")
    parser.add_argument("--offline-models", type=Path, help="完全離線模型根目錄")
    parser.add_argument("--device", choices=("cpu", "cuda", "auto"), default="cpu")
    parser.add_argument("--compute-type", help="預設 CPU int8 / CUDA float16")
    parser.add_argument("--beam-size", type=int, default=5)
    parser.add_argument("--no-diarization", action="store_true")
    parser.add_argument("--verbose", action="store_true", help="顯示第三方套件日誌及相容性警告")
    parser.add_argument("--diarization-device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--num-speakers", type=int)
    parser.add_argument("--min-speakers", type=int)
    parser.add_argument("--max-speakers", type=int)
    parser.add_argument("--cluster-threshold", type=float, default=0.7)
    parser.add_argument("--output", type=Path, help="JSON 路徑，預設 <音檔名>_逐字稿.json；另存同名 .txt")
    return parser


# 交接註解：指定 JSON 路徑時 TXT 取相同檔名；未指定則寫在輸入音檔旁。
def output_paths(args):
    output = args.output or args.audio.with_name(f"{args.audio.stem}_逐字稿.json")
    return output, output.with_suffix(".txt")


# 交接註解：驗證檔案、人數、門檻與輸出衝突；parser.error 會以 SystemExit 結束 CLI。
def validate_args(parser, args):
    if not args.audio.is_file():
        parser.error(f"找不到音檔：{args.audio}")
    if args.beam_size < 1:
        parser.error("beam-size 必須大於 0")
    for key in ("num_speakers", "min_speakers", "max_speakers"):
        if getattr(args, key) is not None and getattr(args, key) < 1:
            parser.error("語者人數必須大於 0")
    if args.num_speakers is not None and (args.min_speakers is not None or args.max_speakers is not None):
        parser.error("num-speakers 不可與 min/max-speakers 同時使用")
    if args.min_speakers and args.max_speakers and args.min_speakers > args.max_speakers:
        parser.error("min-speakers 不可大於 max-speakers")
    if not 0 < args.cluster_threshold < 2:
        parser.error("cluster-threshold 必須介於 0 與 2 之間")
    if args.model_dir and not (args.model_dir / "model.bin").is_file():
        parser.error("model-dir 必須指向包含 model.bin 的 CTranslate2 模型目錄")
    output, text_output = output_paths(args)
    if args.audio.resolve() in (output.resolve(), text_output.resolve()):
        parser.error("輸出路徑不可覆蓋輸入音檔")
    if output.resolve() == text_output.resolve():
        parser.error("JSON 與 TXT 輸出路徑不可相同，請將 --output 設為 .json 檔案")


# 交接註解：完整流程：解碼 → Whisper → 選用語者分離 → 逐字對齊 → 繁體轉換 → JSON/TXT。
def run(args):
    from opencc import OpenCC
    converter = OpenCC("s2twp")
    report_progress(0, "載入音檔與模型")
    local_root = getattr(args, "offline_models", None)
    # 交接註解：離線模式優先使用指定模型根目錄；不採用帳戶 token。
    if local_root:
        local_root = args.offline_models = local_root.resolve()
        from offline_models import configure_offline, validate_models
        configure_offline()
        validate_models(local_root, not args.no_diarization)
        args.model_dir = local_root / "whisper-large-v3-turbo"
    token = os.environ.get("HF_TOKEN")
    # 交接註解：離線模式優先使用指定模型根目錄；不採用帳戶 token。
    if local_root:
        token = None
    if not args.no_diarization and not token and not local_root:
        raise ValueError("請先接受 pyannote/segmentation-3.0 條款並設定 HF_TOKEN，或使用 --no-diarization")
    import ctranslate2
    from faster_whisper import WhisperModel
    from faster_whisper.audio import decode_audio

    device = args.device
    if device == "auto":
        device = "cuda" if ctranslate2.get_cuda_device_count() else "cpu"
    compute_type = args.compute_type or ("float16" if device == "cuda" else "int8")
    if compute_type not in ctranslate2.get_supported_compute_types(device):
        raise ValueError(f"{device} 不支援 compute-type={compute_type}")
    # 交接註解：整段音訊解碼為 16 kHz 單聲道陣列，因此記憶體用量會隨音訊長度增加。
    audio = decode_audio(str(args.audio), sampling_rate=SAMPLE_RATE)
    if not len(audio):
        raise ValueError("音檔沒有可處理的取樣")
    logging.info("載入 Whisper (%s, %s)", device, compute_type)
    model = WhisperModel(str(args.model_dir) if args.model_dir else ASR_MODEL,
                         device=device, compute_type=compute_type,
                         local_files_only=bool(local_root))
    # 交接註解：逐字時間供語者對齊；停用額外 VAD 與前文條件，維持既有模型與轉錄策略。
    iterator, info = model.transcribe(
        audio, beam_size=args.beam_size,
        language=None if args.language == "auto" else args.language,
        initial_prompt=args.initial_prompt, word_timestamps=True,
        vad_filter=False, condition_on_previous_text=False,
    )
    segments = []
    # 交接註解：Whisper generator 在迭代時執行推論；音訊時間比例映射至進度 0–80%。
    for segment in iterator:
        segments.append({"start": segment.start, "end": segment.end, "text": segment.text,
                         "words": [{"start": word.start, "end": word.end, "text": word.word,
                                    "probability": word.probability}
                                   for word in (segment.words or [])]})
        logging.info("轉錄進度 %.1f / %.1f 秒", segment.end, len(audio) / SAMPLE_RATE)
        report_progress(min(80, 80 * segment.end / (len(audio) / SAMPLE_RATE)), "語音轉文字")
    del model
    gc.collect()
    turns = []
    if not args.no_diarization and segments:
        report_progress(80, "辨識不同發言者")
        logging.info("語者分離：pyannote segmentation + SpeechBrain ECAPA")
        turns = diarize(audio, args, token)
    rows = align_words(segments, turns, diarized=not args.no_diarization)
    report_progress(95, "轉換繁體中文與儲存結果")
    # 交接註解：以 OpenCC s2twp 分別轉換整段與逐字文字，兩者可能因詞彙上下文而不同。
    for row in rows:
        row["text"] = converter.convert(row["text"])
        for word in row["words"]:
            word["text"] = converter.convert(word["text"])
    # 交接註解：穩定輸出契約包含語言、音訊時長、模型來源、原始語者區間與對齊後 segments。
    result = {
        "audio": str(args.audio.resolve()), "language": info.language,
        "language_probability": info.language_probability,
        "duration": len(audio) / SAMPLE_RATE,
        "models": {"asr": str(args.model_dir) if args.model_dir else ASR_MODEL,
                   "segmentation": None if args.no_diarization else SEGMENTATION_MODEL,
                   "embedding": None if args.no_diarization else EMBEDDING_MODEL},
        "diarization_enabled": not args.no_diarization,
        "diarization_turns": turns, "segments": rows,
    }
    output, text_output = output_paths(args)
    output.parent.mkdir(parents=True, exist_ok=True)
    # 交接註解：JSON 與 TXT 依序直接寫入，既有檔案會覆寫；此處沒有原子交易。
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [f"[{row['start']:.2f}s - {row['end']:.2f}s] {row['speaker']}: {row['text'].strip()}"
             for row in rows]
    text_output.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    for line in lines:
        print(line)
    logging.info("已儲存：%s", output)
    logging.info("已儲存：%s", text_output)
    report_progress(100, "完成")


# 交接註解：解析與驗證參數後，在訊息管理 context 內執行。
def main():
    parser = build_parser()
    args = parser.parse_args()
    validate_args(parser, args)
    with runtime_messages(args.verbose):
        return execute(args)


# 交接註解：將指定類型例外轉成退出碼 1；成功為 0，其他例外保留原本傳遞方式。
def execute(args):
    started = time.perf_counter()
    try:
        run(args)
    except ImportError:
        logging.error("缺少必要套件，請在目前 Python 環境安裝 requirements.txt")
        return 1
    except (OSError, RuntimeError, ValueError) as error:
        logging.error("執行失敗：%s", error)
        return 1
    logging.info("總耗時 %.1f 秒", time.perf_counter() - started)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
