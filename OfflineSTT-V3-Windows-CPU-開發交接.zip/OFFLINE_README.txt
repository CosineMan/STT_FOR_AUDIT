語音轉文字 V3（Windows x64 / CPU）

1. 將整個 OfflineSTT 資料夾複製到電腦，保留 _internal 與 models。
2. 開啟 OfflineSTT.exe，選擇音檔或音檔資料夾，並選擇可寫入的輸出資料夾。
   資料夾模式處理該層所有支援音檔，不含子資料夾。
3. 語言 auto 為自動偵測；所有 TXT 與 JSON 逐字稿均經 OpenCC 轉成臺灣繁體中文。
4. 需要區分發言者時勾選「辨識不同發言者」。處理時間會增加。
5. 按開始轉錄，畫面顯示目前檔名、檔案進度與整批百分比。
   語者分離期間進度停在 80%，完成後繼續更新。
   完成後每個音檔各輸出 TXT 與 JSON，另存「本次執行紀錄_時間.txt」。
   個別檔案失敗會繼續下一個，紀錄包含完整檔案清單、成功與失敗結果。
   同名不同格式音檔自動加編號，避免互相覆寫。既有結果會先詢問是否覆寫。

不需 Python、不需 Hugging Face token、不需網路。模型遺失時請重新複製完整套件。
請等待工作完成後關閉程式。長錄音會佔用較多記憶體；速度取決於 CPU。
發言者標籤只在單一檔案中有效，不辨識真實姓名。重疊發言可能誤配或遺漏。

模型來源與修訂、SHA256 記錄於 models/manifest.json。
轉錄：mobiuslabsgmbh/faster-whisper-large-v3-turbo（OpenAI Whisper 的 CTranslate2 轉換）
分段：pyannote/segmentation-3.0
語者特徵：speechbrain/spkrec-ecapa-voxceleb
隨附 licenses 資料夾包含第三方授權、模型來源與說明，分享時請一併保留。

可按「取消作業」中斷目前轉錄與後續排程；已完成結果保留。
中斷檔案可能有不完整輸出，請重新轉錄。取消完成後可再次開始。
