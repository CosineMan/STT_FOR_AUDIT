"""Collect installed distribution notices and public upstream model notices."""
import importlib.metadata
from pathlib import Path
import shutil
import sys
import urllib.request


# 交接註解：開發端工具：收集已安裝套件授權，並連網下載模型公開告知；不在離線推論時呼叫。
def main():
    root = Path('licenses')
    root.mkdir(exist_ok=True)
    python_license = Path(sys.base_prefix) / 'LICENSE_PYTHON.txt'
    if not python_license.exists():
        python_license = Path(sys.base_prefix) / 'LICENSE.txt'
    if python_license.is_file():
        shutil.copyfile(python_license, root / 'Python-LICENSE.txt')
    for dist in importlib.metadata.distributions():
        folder = root / dist.metadata['Name']
        for item in dist.files or []:
            if any(part.lower().startswith(('license', 'copying', 'notice')) for part in item.parts):
                source = Path(dist.locate_file(item))
                if source.is_file():
                    folder.mkdir(exist_ok=True)
                    # Retain relative structure to avoid colliding bundled notices.
                    dest = folder.joinpath(*[p for p in item.parts if p not in ('.', '..')])
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(source, dest)
    urls = {
        'whisper-MIT.txt': 'https://raw.githubusercontent.com/openai/whisper/main/LICENSE',
        'whisper-model-card.md': 'https://huggingface.co/mobiuslabsgmbh/faster-whisper-large-v3-turbo/raw/main/README.md',
        'segmentation-model-info.json': 'https://huggingface.co/api/models/pyannote/segmentation-3.0',
        'pyannote-MIT.txt': 'https://raw.githubusercontent.com/pyannote/pyannote-audio/3.3.2/LICENSE',
        'speechbrain-model-card.md': 'https://huggingface.co/speechbrain/spkrec-ecapa-voxceleb/raw/main/README.md',
        'speechbrain-Apache-2.0.txt': 'https://raw.githubusercontent.com/speechbrain/speechbrain/v1.0.3/LICENSE',
    }
    folder = root / 'models'
    folder.mkdir(exist_ok=True)
    for name, url in urls.items():
        request = urllib.request.Request(url)
        with urllib.request.urlopen(request, timeout=45) as response:
            (folder / name).write_bytes(response.read())
        print(name, flush=True)
    (folder / 'sources.txt').write_text('\n'.join(f'{name}: {url}' for name, url in urls.items()), encoding='utf-8')


if __name__ == '__main__':
    main()
