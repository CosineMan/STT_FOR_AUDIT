# V2 驗證（2026-11-01）

- 14 項單元測試通過；新增資料夾掃描、同名音檔輸出避碰、OpenCC 臺灣繁體轉換與進度協定測試。
- 真實批次流程：2 個正常音檔加 1 個損壞音檔，成功 2、失敗 1，失敗後繼續執行；測試以輕量 UI 替身驅動實際桌面流程及子程序。
- 本次執行紀錄包含完整檔案清單、成功／失敗原因、輸出位置；中文資料夾路徑通過。
- V2 EXE 在中文含空白路徑、空白快取、精簡 PATH 與不同工作目錄完成實際轉錄及語者分離；進度單調遞增並達 100%。
- V2 EXE 缺少模型時正確失敗，不嘗試下載模型。
- pip check 通過。
- 未完成新版視窗的視覺操作驗收，亦未在另一台無 Python 的乾淨 Windows 電腦驗收。
- 批次實測紀錄：build/v2-batch-report.txt；單元測試：build/v2-unit-tests.log；封裝測試：build/v2-frozen-smoke.log。
- 打包：build/v2-build.log；ZIP 模型 SHA256、ZIP CRC 與壓縮檔雜湊：build/v2-release.log 與 dist/OfflineSTT-V2-Windows-CPU.zip.sha256。

# 離線 CPU 版驗證記錄（2026-11-01）

- 11 項單元測試通過，涵蓋對齊、參數驗證、訊息過濾、離線模型檢查與 SpeechBrain 本機載入。
- 獨立 Python 3.12 / CPU PyTorch 環境通過 `pip check`。
- 原始碼實際推論：移除 HF token、使用空白 HF_HOME，阻擋 Python socket 連線，20 秒音訊完成轉錄與語者分離。
- 封裝後 exe 實際推論：使用空白 HF/Torch 快取、僅有 Windows System32 的 PATH、不同工作目錄及中文含空白的音檔路徑，成功輸出 TXT 與 JSON，包含語者區間。
- 封裝後 exe 缺少模型時立即回報離線模型不完整，不要求登入。
- 封裝後 20 秒樣本完整流程約 60 秒；這是本機單次測試，不代表其他電腦的效能。
- Windows 桌面視窗曾成功建立；computer-use 畫面擷取連續逾時，尚未完成選檔、開始按鈕及進度顯示的視覺操作驗收。
- 尚未在另一台未安裝 Python、實際斷網的乾淨 Windows 電腦驗收。

修正：固定 PyAV 18.1.0；補上 Lightning 套件資料檔；SpeechBrain 使用本機權重與暫存複製策略。
版本記錄：`requirements-build.lock.txt` 與發佈資料夾的 `build-versions.txt`。
模型 SHA256：`models/manifest.json`。建立 ZIP 時逐一核對模型 SHA256、檢查 ZIP CRC 並產生 ZIP SHA256。

重新驗證：

```powershell
.\.venv-build\Scripts\python.exe -m unittest discover -s tests -v
.\.venv-build\Scripts\python.exe tests/offline_smoke.py
.\.venv-build\Scripts\python.exe tests/frozen_smoke.py
.\.venv-build\Scripts\python.exe create_release.py
```

整合測試使用 `build/smoke.wav`，不將測試錄音或逐字稿放入發佈資料夾。
