# Whisper 轉錄與語者分離

## 離線 Windows 桌面版

`stt_desktop.py` 提供 CPU 離線介面；選擇音檔或音檔資料夾、輸出資料夾、語言與是否分離語者。

第二版支援該層資料夾批次轉錄（不遞迴子資料夾），以 OpenCC s2twp 將 TXT 與 JSON 的文字轉成臺灣繁體。
畫面顯示目前檔名、檔案順序、單檔與整批百分比；整批進度以檔案數平均計算，並非剩餘時間估計。
轉錄佔單檔進度 0–80%，語者分離期間維持 80%，儲存完成才達 100%。
每次在輸出資料夾留下「本次執行紀錄_時間.txt」，包含全部輸入路徑、成功／失敗與輸出路徑。
單檔失敗會繼續處理下一個，同名不同副檔名的輸出自動加編號。
`models` 必須放在 exe 旁，路徑以程式位置解析，不依賴啟動時的工作目錄。

開發端建立獨立環境（目前打包使用 Python 3.12）：

```powershell
python -m venv .venv-build
.\.venv-build\Scripts\python.exe -m pip install torch==2.5.1 torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv-build\Scripts\python.exe -m pip install -r requirements.txt pyinstaller -c requirements-build.lock.txt
python prepare_models.py
.\.venv-build\Scripts\python.exe collect_licenses.py
.\.venv-build\Scripts\python.exe stt_desktop.py
.\build_offline.ps1
.\.venv-build\Scripts\python.exe tests/frozen_smoke.py
.\.venv-build\Scripts\python.exe create_release.py
```

`prepare_models.py` 複製目前帳戶快取中的三套模型 snapshot，實體化符號連結，
不複製 Hugging Face 帳戶 token。模型來源修訂及 SHA256 記錄於 `models/manifest.json`。
SpeechBrain 的可選 `custom.py` 在本機載入模式需存在，因此準備腳本產生空白模組並記錄於 manifest。
語者模型載入時會使用可寫入的暫存目錄，載入後清除，不寫入程式安裝目錄。

命令列離線用法：

```powershell
python stt_with_large_v3.py test.m4a --offline-models models --language zh
```

此模式設定 `HF_HUB_OFFLINE=1`，先驗證必要檔案，不要求 token。
語者分離使用本機 segmentation checkpoint 與 SpeechBrain 權重，禁止隱含使用 HF token。
離線短音訊驗證：先準備 `build/smoke.wav`，再執行 `python tests/offline_smoke.py`；
此腳本阻擋 Python socket 連線並移除 token，執行實際轉錄及分離。

發佈整個 `dist/OfflineSTT` 資料夾，不可只複製 exe。
`build-versions.txt` 記錄實際打包環境。發佈前仍需在無 Python、無快取的離線 Windows
機器上驗收，並檢查隨附模型及套件授權。不要把 `.venv-build`、原始錄音或開發帳戶快取交付。
`requirements-build.lock.txt` 固定已測試的相依版本；CPU PyTorch 需先從上述 CPU index 安裝。
PyAV 固定 18.1.0，避免 19.x 移除 `metadata_errors` 造成 faster-whisper 音訊讀取失敗。
`collect_licenses.py` 只在開發端連網收集官方公開資料，不使用或保存帳戶 token。
`create_release.py` 核對模型 SHA256、產生 `dist/OfflineSTT-V2-Windows-CPU.zip`、檢查 ZIP 完整性，
並另存 `.zip.sha256`。測試結果與尚未完成的驗收項目見 `RELEASE_VALIDATION.md`。

建議在獨立 Python 3.10 / 3.11 環境執行，避免修改原有環境。此版本保留 large-v3-turbo，以 CPU int8 為預設；語言預設自動偵測，移除未使用的路徑、套件與 KMP_DUPLICATE_LIB_OK 環境覆寫。

## 安裝與執行（PowerShell）

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

先登入 https://huggingface.co/pyannote/segmentation-3.0 接受模型使用條款，再建立有該模型讀取權限的 Hugging Face token。只轉錄可加 `--no-diarization`，不需要此 token。

```powershell
$env:HF_TOKEN = Read-Host 'Hugging Face token' -MaskInput
.\.venv\Scripts\python.exe stt_with_large_v3.py cnn_anderson_cooper.m4a --language en --num-speakers 2
.\.venv\Scripts\python.exe stt_with_large_v3.py test.m4a --language zh --initial-prompt '以下是繁體中文的逐字稿。'
.\.venv\Scripts\python.exe stt_with_large_v3.py test.m4a --no-diarization
```

`-MaskInput` 需要 PowerShell 7.1 以上。不要把 token 寫入程式或提交至版本控制。首次執行會下載模型，推論在本機進行。模型條款須由使用者自行接受。

其他選項：

- `--verbose`：顯示 SpeechBrain / NumExpr 日誌與指定的相容性警告。預設保留程式進度、第三方 WARNING / ERROR 及其他未列出的警告，只隱藏 pandas 的 numexpr / bottleneck 版本提示、SpeechBrain 舊 AMP API 提示，以及目前固定版本模型載入流程的 `weights_only=False` 提示。這是訊息過濾，不會改變模型反序列化行為或提升推論速度；只載入可信任的模型。requirements.txt 已加入相容的 numexpr / bottleneck 下限，重新安裝相依套件可解決其版本問題；程式不會自行更新既有 Anaconda 環境。
- `--device cuda`：Whisper 使用 NVIDIA GPU；需符合 CTranslate2 的 CUDA/cuDNN 要求。
- `--diarization-device cuda`：語者分離也使用 GPU；需另安裝相符版本的 CUDA PyTorch/torchaudio。兩階段分開控制，預設皆 CPU。
- `--model-dir 'D:\models\large-v3-turbo'`：使用既有 CTranslate2 模型。HF 快取應指向 `snapshots/<revision>` 下含 `model.bin` 的目錄，不是 `models--...` 根目錄。使用者提供模型需自行確認來源。
- `--min-speakers 2 --max-speakers 5`：限制人數範圍，不能和 `--num-speakers` 並用。
- `--cluster-threshold 0.7`：自訂聚類門檻，須以代表性錄音校準；較高值通常更容易合併語者。
- `--output result.json`：指定 JSON 輸出，並在同一目錄另存 `result.txt`；既有輸出檔會被覆寫。

## 模型來源與限制

明確指定以下模型，不使用整套預設 diarization pipeline，避免間接載入 WeSpeaker：

| 用途 | 模型及來源 |
| --- | --- |
| 轉錄 | [OpenAI Whisper large-v3-turbo](https://huggingface.co/openai/whisper-large-v3-turbo)，使用 [Mobius Labs 的 CTranslate2 轉換](https://huggingface.co/mobiuslabsgmbh/faster-whisper-large-v3-turbo) |
| 語音／語者活動分段 | [pyannote/segmentation-3.0](https://huggingface.co/pyannote/segmentation-3.0)，pyannote／法國 CNRS 研究團隊 |
| 語者特徵 | [speechbrain/spkrec-ecapa-voxceleb](https://huggingface.co/speechbrain/spkrec-ecapa-voxceleb)，SpeechBrain 國際研究團隊，專案源於加拿大 Concordia／Mila |

這裡的限制按模型開發／發布專案來源落實，不按研究者姓名判斷。未選用中國開發的模型；也關閉 faster-whisper 的額外 VAD 模型。pyannote community-1 模型卡引用 WeSpeaker，因此沒有採用。模型來源說明不代表訓練資料不包含中國來源資料。

此自訂 pyannote + SpeechBrain 組合使用初始聚類參數，不能沿用官方整套 pipeline 的準確率宣稱。使用固定 pyannote 3.3.2 介面，不可直接升級為 4.x。Windows 下程式會在 pyannote 載入 SpeechBrain（含 GPU 切換）時使用 `LocalStrategy.COPY`，避免建立符號連結造成 `WinError 1314`；不需管理員權限或開發人員模式，會多佔用一些快取空間。此相容處理只在模型初始化期間生效，不修改已安裝套件。

Hugging Face 的 symlink 快取警告表示改用較佔空間的快取方式，並不會中止執行。`HF_HUB_DISABLE_SYMLINKS_WARNING` 只能隱藏該警告，無法修正 SpeechBrain 的權限錯誤。若既有 Anaconda 環境另出現 pandas 對 numexpr / bottleneck 的版本警告，可在該環境執行 `python -m pip install "numexpr>=2.10.2" "bottleneck>=1.4.2"`；這兩項警告與此次權限錯誤無關。

## 輸出與品質

預設寫出音檔旁的 `<音檔名>_逐字稿.json` 與 `<音檔名>_逐字稿.txt`（音檔名不含副檔名）。例如 `訪談.m4a` 會產生 `訪談_逐字稿.json` 與 `訪談_逐字稿.txt`。TXT 使用 UTF-8，每行與終端機逐字稿相同，格式為 `[0.72s - 10.82s] SPEAKER_00: 文字內容`。

JSON 包含語言、模型來源、逐字時間／機率、語者標籤及原始語者活動區間。逐字最大重疊決定主要語者；無重疊標記 UNKNOWN，未啟用分離則為 UNASSIGNED。speaker_candidates 是時間重疊候選，並非聲紋可信度，也不一定表示同時發言。原始 diarization_turns 保留重疊區間。

語者分離是標記「何時誰說話」，不會抽出各人的獨立音軌，也不辨識真實姓名；標籤只在單一檔案內有效。重疊發言的文字仍可能遺漏或誤配。繁體提示詞不保證全繁體；台語品質也需實測。停用前文條件可降低循環重複，但可能犧牲跨段連貫性。完整音訊會載入記憶體，超長錄音需留意 RAM。

## 驗證

```powershell
python -m unittest discover -s tests -v
python stt_with_large_v3.py --help
```

測試涵蓋時間對齊、參數驗證，以及 Windows 複製策略與載入失敗後的還原，不需下載模型。實際辨識／分離品質與 GPU 相容性仍須透過完整音訊推論驗證。

第三版：視窗標題為「語音轉文字 V3」。執行中可按「取消作業」停止目前程序與後續檔案；完成的結果保留，紀錄列出取消與未執行檔案。取消完成後可重新開始。中斷檔案輸出可能不完整，應重新轉錄。
