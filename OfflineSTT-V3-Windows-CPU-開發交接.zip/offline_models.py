"""Offline package model contract; no third-party imports here."""
import os
from pathlib import Path
import sys

# 交接註解：離線模型最低檔案契約；manifest 的 SHA256 驗證在發佈階段另行執行。
FILES = {
    "whisper-large-v3-turbo": ("model.bin", "config.json", "tokenizer.json", "preprocessor_config.json"),
    "segmentation": ("pytorch_model.bin",),
    "speaker-embedding": ("hyperparams.yaml", "embedding_model.ckpt", "mean_var_norm_emb.ckpt",
                          "classifier.ckpt", "label_encoder.txt"),
}


# 交接註解：EXE 以執行檔所在目錄為根；原始碼以此模組所在目錄為根，不依賴 cwd。
def app_root():
    return Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent


# 交接註解：強制 HF 離線、停用遙測與隱含 token；這些設定不是作業系統防火牆。
def configure_offline():
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"


# 交接註解：只驗證必要檔案存在；不啟用分離時僅要求 Whisper。SpeechBrain 額外要求 custom.py。
def validate_models(root, diarization=True):
    root = Path(root)
    missing = [str(root / folder / name) for folder, names in FILES.items()
               if diarization or folder == "whisper-large-v3-turbo"
               for name in names if not (root / folder / name).is_file()]
    if diarization and not (root / "speaker-embedding" / "custom.py").is_file():
        missing.append(str(root / "speaker-embedding" / "custom.py"))
    if missing:
        raise ValueError("離線模型不完整，請重新複製完整 models 資料夾：\n" + "\n".join(missing))
